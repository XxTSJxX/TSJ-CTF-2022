#!/bin/bash

timeout 300 \
    /home/pekora/qemu-system-x86_64 \
    -L /home/pekora/data \
    -kernel /home/pekora/bzImage \
    -initrd /home/pekora/initramfs.cpio.gz \
    -cpu kvm64,+smep,+smap \
    -m 256M \
    -monitor none \
    -append "console=ttyS0 oops=panic panic=1 quiet" \
    -no-reboot \
    -nographic \
    -sandbox on \
    -device rabbit
