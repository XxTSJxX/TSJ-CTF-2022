# Description

* ***`encoder.exe` IS A REAL MALWARE! PLEASE SOLVE THIS CHALLENGE IN A VIRTUAL MACHINE ENVIRONMENT!!!***
* `infected_C_drive` contains TSJ's infected C drive. The flag is concealed in one of the files in TSJ's infected C drive.
* `encoder.exe` is the malware than encrypted TSJ's C drive, while `encoder.DMP` is the dump file. Analyze both files to recover TSJ's C drive and procure the flag.
* The flag is an ASCII art.
